<?php
if(is_admin()){
	require CLOUDPRESS_DARK_TEMPLATE_DIR . '/admin/inc/class-spicethemes-about-page.php';
}

require CLOUDPRESS_DARK_TEMPLATE_DIR . '/admin/inc/plugin-include-control.php';
require CLOUDPRESS_DARK_TEMPLATE_DIR . '/admin/inc/include-companion.php';
