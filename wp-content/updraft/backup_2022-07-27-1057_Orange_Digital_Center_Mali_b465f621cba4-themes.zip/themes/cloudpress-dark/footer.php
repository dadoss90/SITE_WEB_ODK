<?php
do_action('cloudpress_dark_footer_section_hook');?>
</div>
<?php wp_footer();?>
</body>
</html>
